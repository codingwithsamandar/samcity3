from django.conf import settings
from django.conf.urls.static import static
from django.urls import path,include
from django.contrib import admin

urlpatterns = [
    path('admin/', admin.site.urls),
    # Til almashtirish (set_language) — cookie o'rnatadi, oldingi sahifaga qaytaradi.
    path('i18n/', include('django.conf.urls.i18n')),
    path('', include('main.urls')),
    path('delivery/', include('delivery.urls', namespace='delivery')),
    path('payments/', include('payments.urls', namespace='payments')),
    path('booking/', include('booking.urls')),
    path('notifications/', include('notifications.urls')),
    path('map/', include('places.urls')),
    path('ai/', include('assistant.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
    # ── Mobil REST API (Flutter ilova) ──
    path('api/', include('api.urls', namespace='api')),
]

# ── Taksi arxivlangan: yo'llar faqat TAXI_ENABLED=True bo'lsa ulanadi ────────
if settings.TAXI_ENABLED:
    urlpatterns.append(path('taxi/', include('taxi.urls', namespace='taxi')))

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

