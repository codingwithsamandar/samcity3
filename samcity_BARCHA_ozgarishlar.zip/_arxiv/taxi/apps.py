from django.apps import AppConfig


class TaxiConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'taxi'
    verbose_name = 'Taksi'
