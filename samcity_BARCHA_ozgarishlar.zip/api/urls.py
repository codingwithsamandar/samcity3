"""
SamCity mobil API marshrutlari.
Barchasi `/api/` prefiksi ostida (sdev/urls.py da ulanadi).
"""
from django.conf import settings
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

from .views import (
    RegisterView, VerifyOTPView, ResendOTPView, LoginView, MeView, AdViewSet,
)
from .delivery_views import (
    StoreViewSet, OrderViewSet, CartView,
    CartListCreateView, CartManageView, CartActivateView, CartAdView,
    cart_add, cart_set, cart_remove, checkout,
    MyStoresView, MyStoreDetailView, StoreProductsView, StoreProductDetailView,
    StoreUpdatesView, StoreSubscribeToggleView, StoreAnnouncementCreateView,
    StoreOrdersView, StoreOrderStatusView, OrderConfirmPickupView,
    StoreRequestView, CatalogListView,
)
from .courier_views import (
    CourierDashboardView, CourierRegisterView, CourierProfileView,
    CourierAvailableView, CourierAcceptView, CourierReleaseView,
    CourierOrderStatusView,
)
from .chat_store_views import (
    StoreChatStartView, StoreChatThreadView, StoreChatListView,
)
from .mahalla_views import (
    MahallaListView, MahallaDetailView, AnnouncementCreateView,
    ComplaintListCreateView, ComplaintStatusView,
    HokimPanelView, DistrictAnnounceView,
)
from .booking_views import (
    VenueViewSet, VenueBookingViewSet,
    VenueOwnerBookingsView, VenueOwnerBookingActionView, MyVenuesView,
    MyVenueDetailView, MyVenueServiceView, MyVenueServiceDeleteView,
    MyVenueStaffView, MyVenueStaffDeleteView,
)
from .notifications_views import (
    NotificationListView, NotificationUnreadCountView, NotificationMarkReadView,
    DeviceTokenView,
)
from .payment_views import InitiatePaymentView
from .health import HealthView, ReadyView, SeedStatusView
from .places_views import PlacesListView
from .community_views import PollListView, poll_vote, poll_comments, HelpListView
from .jobs_views import JobListView, ResumeListView
from .service_views import (
    ProvidersListView, CreateServicePaymentView,
)
from .assistant_views import (
    AssistantChatView, AssistantTTSView, AssistantSTTView,
    AssistantConfirmView, AssistantCancelView,
)

app_name = 'api'

router = DefaultRouter()
router.register('ads', AdViewSet, basename='ad')
router.register('stores', StoreViewSet, basename='store')
router.register('orders', OrderViewSet, basename='order')

# ── Taksi arxivlangan: endpointlar faqat TAXI_ENABLED=True bo'lsa ochiladi ───
taxi_patterns = []
if settings.TAXI_ENABLED:
    from .taxi_views import (
        TaxiServiceViewSet, TaxistViewSet, TripViewSet,
        TaxistMeView, TaxistRegisterView, TaxistOnlineToggleView,
        TaxistRouteCreateView, TaxistRouteDeleteView,
    )
    router.register('taxi/services', TaxiServiceViewSet, basename='taxi-service')
    router.register('taxi/taxists', TaxistViewSet, basename='taxist')
    router.register('taxi/trips', TripViewSet, basename='trip')
    taxi_patterns = [
        path('taxi/me/', TaxistMeView.as_view(), name='taxist-me'),
        path('taxi/me/register/', TaxistRegisterView.as_view(), name='taxist-register'),
        path('taxi/me/online/', TaxistOnlineToggleView.as_view(), name='taxist-online'),
        path('taxi/me/routes/', TaxistRouteCreateView.as_view(), name='taxist-route-create'),
        path('taxi/me/routes/<uuid:route_id>/', TaxistRouteDeleteView.as_view(), name='taxist-route-delete'),
    ]
router.register('booking/venues', VenueViewSet, basename='venue')
router.register('booking/bookings', VenueBookingViewSet, basename='venue-booking')

auth_patterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('verify-otp/', VerifyOTPView.as_view(), name='verify-otp'),
    path('resend-otp/', ResendOTPView.as_view(), name='resend-otp'),
    path('login/', LoginView.as_view(), name='login'),
    path('refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('me/', MeView.as_view(), name='me'),
]

cart_patterns = [
    path('', CartView.as_view(), name='cart'),
    path('add/', cart_add, name='cart-add'),
    path('set/', cart_set, name='cart-set'),
    path('remove/', cart_remove, name='cart-remove'),
    # E'lon saqlash (savatning e'lonlar bo'limi)
    path('ad/', CartAdView.as_view(), name='cart-ad'),
    # Saqlangan (nomli) savatlar
    path('carts/', CartListCreateView.as_view(), name='cart-list'),
    path('carts/<int:cart_id>/', CartManageView.as_view(), name='cart-manage'),
    path('carts/<int:cart_id>/activate/', CartActivateView.as_view(), name='cart-activate'),
]

urlpatterns = [
    path('auth/', include(auth_patterns)),
    path('cart/', include(cart_patterns)),
    path('catalog/', CatalogListView.as_view(), name='catalog'),
    path('checkout/', checkout, name='checkout'),
    path('my/stores/', MyStoresView.as_view(), name='my-stores'),
    path('stores/request/', StoreRequestView.as_view(), name='store-request'),
    path('my/stores/<int:store_pk>/', MyStoreDetailView.as_view(), name='my-store-detail'),
    path('stores/<int:store_pk>/products/', StoreProductsView.as_view(), name='store-products'),
    path('stores/<int:store_pk>/products/<int:product_pk>/', StoreProductDetailView.as_view(), name='store-product-detail'),
    path('stores/<int:store_pk>/updates/', StoreUpdatesView.as_view(), name='store-updates'),
    path('stores/<int:store_pk>/subscribe/', StoreSubscribeToggleView.as_view(), name='store-subscribe'),
    path('stores/<int:store_pk>/announce/', StoreAnnouncementCreateView.as_view(), name='store-announce'),
    # Egasi buyurtma boshqaruvi + mijoz pickup tasdig'i
    path('my/orders/', StoreOrdersView.as_view(), name='my-orders'),
    path('my/orders/<uuid:order_id>/status/', StoreOrderStatusView.as_view(), name='my-order-status'),
    path('orders/<uuid:order_id>/confirm-pickup/', OrderConfirmPickupView.as_view(), name='order-confirm-pickup'),
    # ── Kuryer (yetkazib beruvchi) mobil paneli ──
    path('courier/', CourierDashboardView.as_view(), name='courier-dashboard'),
    path('courier/register/', CourierRegisterView.as_view(), name='courier-register'),
    path('courier/profile/', CourierProfileView.as_view(), name='courier-profile'),
    path('courier/available/', CourierAvailableView.as_view(), name='courier-available'),
    path('courier/orders/<uuid:order_id>/accept/', CourierAcceptView.as_view(), name='courier-accept'),
    path('courier/orders/<uuid:order_id>/release/', CourierReleaseView.as_view(), name='courier-release'),
    path('courier/orders/<uuid:order_id>/status/', CourierOrderStatusView.as_view(), name='courier-order-status'),
    # ── Taksi haydovchi (taksist) mobil paneli — arxivlangan (TAXI_ENABLED) ──
    *taxi_patterns,
    # ── To'yxona/joy egasi — bron boshqaruvi (mobil) ──
    path('booking/manage/', VenueOwnerBookingsView.as_view(), name='venue-owner-bookings'),
    path('booking/manage/<uuid:booking_id>/<str:action>/', VenueOwnerBookingActionView.as_view(), name='venue-owner-action'),
    path('booking/my-venues/', MyVenuesView.as_view(), name='my-venues'),
    # Egasi joy setup — xizmat/usta o'chirish (specific-first, konfliktsiz)
    path('booking/my-venues/services/<uuid:service_id>/', MyVenueServiceDeleteView.as_view(), name='my-venue-service-delete'),
    path('booking/my-venues/staff/<uuid:staff_id>/', MyVenueStaffDeleteView.as_view(), name='my-venue-staff-delete'),
    path('booking/my-venues/<uuid:venue_id>/', MyVenueDetailView.as_view(), name='my-venue-detail'),
    path('booking/my-venues/<uuid:venue_id>/services/', MyVenueServiceView.as_view(), name='my-venue-service-add'),
    path('booking/my-venues/<uuid:venue_id>/staff/', MyVenueStaffView.as_view(), name='my-venue-staff-add'),
    # Do'kon bilan chat (mijoz ↔ do'kon)
    path('stores/<int:store_pk>/chat/', StoreChatStartView.as_view(), name='store-chat-start'),
    path('delivery/chat/threads/', StoreChatListView.as_view(), name='store-chat-list'),
    path('delivery/chat/threads/<int:thread_id>/', StoreChatThreadView.as_view(), name='store-chat-thread'),
    # ── Mahalla bo'limi ──
    path('mahalla/', MahallaListView.as_view(), name='mahalla-list'),
    path('mahalla/<int:pk>/', MahallaDetailView.as_view(), name='mahalla-detail'),
    path('mahalla/<int:pk>/announce/', AnnouncementCreateView.as_view(), name='mahalla-announce'),
    path('mahalla/<int:pk>/complaints/', ComplaintListCreateView.as_view(), name='mahalla-complaints'),
    path('mahalla/complaints/<uuid:req_id>/status/', ComplaintStatusView.as_view(), name='mahalla-complaint-status'),

    # ── Hokim paneli (tuman e'loni) ──
    path('hokim/', HokimPanelView.as_view(), name='hokim-panel'),
    path('hokim/<int:pk>/announce/', DistrictAnnounceView.as_view(), name='hokim-announce'),
    path('notifications/', NotificationListView.as_view(), name='notifications'),
    path('notifications/unread-count/', NotificationUnreadCountView.as_view(), name='notifications-unread-count'),
    path('notifications/read/', NotificationMarkReadView.as_view(), name='notifications-read'),
    path('notifications/device/', DeviceTokenView.as_view(), name='notifications-device'),
    path('payments/initiate/', InitiatePaymentView.as_view(), name='payments-initiate'),
    path('health/', HealthView.as_view(), name='health'),
    path('ready/', ReadyView.as_view(), name='ready'),
    path('seed-status/', SeedStatusView.as_view(), name='seed-status'),
    path('places/', PlacesListView.as_view(), name='places'),
    path('community/polls/', PollListView.as_view(), name='polls'),
    path('community/polls/<uuid:poll_id>/vote/', poll_vote, name='poll-vote'),
    path('community/polls/<uuid:poll_id>/comments/', poll_comments, name='poll-comments'),
    path('community/help/', HelpListView.as_view(), name='help'),
    path('jobs/', JobListView.as_view(), name='jobs'),
    path('resumes/', ResumeListView.as_view(), name='resumes'),
    path('service/providers/', ProvidersListView.as_view(), name='service-providers'),
    path('service/pay/', CreateServicePaymentView.as_view(), name='service-pay'),
    # ── AI yordamchi (mobil Flutter ilova) ──
    path('assistant/chat/', AssistantChatView.as_view(), name='assistant-chat'),
    path('assistant/tts/', AssistantTTSView.as_view(), name='assistant-tts'),
    path('assistant/stt/', AssistantSTTView.as_view(), name='assistant-stt'),
    path('assistant/confirm/<uuid:action_id>/', AssistantConfirmView.as_view(),
         name='assistant-confirm'),
    path('assistant/cancel/<uuid:action_id>/', AssistantCancelView.as_view(),
         name='assistant-cancel'),
    path('', include(router.urls)),
    # Hujjat (OpenAPI / Swagger)
    path('schema/', SpectacularAPIView.as_view(), name='schema'),
    path('docs/', SpectacularSwaggerView.as_view(url_name='api:schema'), name='docs'),
]
